function [trodeInd unitInd] = getUnitInfo(unitTag)
% function [trodeInd unitInd] = getUnitInfo(unitTag)
 C= textscan(unitTag,'%c%d_%d');
 trodeInd = C{2};
 unitInd = C{3};