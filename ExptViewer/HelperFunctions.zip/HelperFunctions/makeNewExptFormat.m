function newexpt = makeNewExptFormat(expt)
% function newexpt = makeNewExptFormat(expt)
% BA 0419
% newexpt = expt;

msgbox('You need to fix makeNewExptFormat') 

% if isfield(expt.sort,'tetrode')
%     newexpt.sort.trode = newexpt.sort.tetrode;
%     newexpt.sort = rmfield(newexpt.sort,'tetrode');  
% end
% 
% for i = 1:length(newexpt.sort.trode)
%     for j = 1:length(newexpt.sort.trode(i).unit)
%         if ~isfield(newexpt.sort.trode(i).unit(j),'label')
%             newexpt.sort.trode(i).unit(j).label = [];
%         end
%     end
% end
%  
% if isfield(newexpt.sort.trode,'files')
%     for i = 1:length(newexpt.sort.trode)
%         newexpt.sort.trode(i).fileInds = newexpt.sort.trode(i).files;
%     end
%     newexpt.sort.trode = rmfield(newexpt.sort.trode,'files');
% end
% 
% for  i = 1:length(newexpt.sort.trode)
%     if ~isfield(newexpt.sort.trode(i),'name')
%         newexpt.sort.trode(i).name = sprintf('T%d',i);
%     end
%     
%     
%     for j = 1:size(newexpt.sort.trode(i).unit,2)
%         if ~isfield(newexpt.sort.trode(i).unit,'assign')
%             newexpt.sort.trode(i).unit(j).assign = newexpt.sort.trode(i).unit(j).index;
%         end
%         if ~isfield(newexpt.sort.trode(i).unit(j),'spikewaveform')
%             newexpt.sort.trode(i).unit(j).spikewaveform = [];
%         end
%         if ~isfield(newexpt.sort.trode(i).unit(j).spikewaveform,'waveformtype')
%             newexpt.sort.trode(i).unit(j).spikewaveform.waveformtype = NaN;
%             newexpt.sort.trode(i).unit(j).spikewaveform.amplitude = NaN;
%         end
%     end
% end
% 
% if  isfield(newexpt.sort.trode(i).unit,'index')
%     newexpt.sort.trode(i).unit = rmfield(newexpt.sort.trode(i).unit,'index');
% end
%     
% newexpt.info.structversion = 1.0;